package ua.dp.levelup.service;

/**
 * @author Alexandr Shegeda on 23.06.17.
 */
public interface FilmService { }
