package ua.dp.levelup.dao;

import ua.dp.levelup.core.model.Film;

/**
 * @author Alexandr Shegeda on 23.06.17.
 */
public interface FilmDao {

    void createFilm(Film film);
}
