package test;

/**
 * Created by java on 17.01.2017.
 */
public abstract class Component {

    public void show() {
        System.out.println("Show from component");
    }
}
