package model;

/**
 * Created by java on 13.01.2017.
 */
public abstract class Employee {

    protected static double baseRate = 500;

    public abstract void calculateSalary();

}
