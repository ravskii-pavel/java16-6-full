package autosalon;

/**
 * Created by java on 17.01.2017.
 */
public interface Action {

    void stop();
    void drive();
    void beep();

}
