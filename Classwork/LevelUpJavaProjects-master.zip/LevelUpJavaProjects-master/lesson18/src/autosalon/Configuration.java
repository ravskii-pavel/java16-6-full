package autosalon;

/**
 * Created by java on 13.01.2017.
 */
public enum Configuration {

    BASIC, LUX, EXCLUSIVE
}
