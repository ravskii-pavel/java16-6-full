package com.levelup.view;

import java.util.List;

/**
 * Created by java on 10.01.2017.
 */
public interface Action {

    void create();
    void read();
    void update();
    void delete();

}
