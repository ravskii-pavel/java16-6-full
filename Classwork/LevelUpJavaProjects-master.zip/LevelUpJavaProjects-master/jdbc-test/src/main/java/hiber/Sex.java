package hiber;

/**
 * Created by java on 07.04.2017.
 */
public enum  Sex {

    MALE, FEMALE, UNKNOWN

}
