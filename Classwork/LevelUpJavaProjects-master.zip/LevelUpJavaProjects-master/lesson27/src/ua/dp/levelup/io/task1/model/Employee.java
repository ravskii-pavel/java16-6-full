package ua.dp.levelup.io.task1.model;

/**
 * Created by java on 21.02.2017.
 */
public abstract class Employee {
}
