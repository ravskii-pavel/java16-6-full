package ua.dp.levelup.dao.impl;

import ua.dp.levelup.dao.MovieSessionDao;

/**
 * @author Alexandr Shegeda on 23.06.17.
 */
public class MovieSessionDaoImpl implements MovieSessionDao{ }
