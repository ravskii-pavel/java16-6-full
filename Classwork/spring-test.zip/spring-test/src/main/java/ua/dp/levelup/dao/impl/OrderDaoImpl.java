package ua.dp.levelup.dao.impl;

import ua.dp.levelup.dao.OrderDao;

/**
 * @author Alexandr Shegeda on 23.06.17.
 */
public class OrderDaoImpl implements OrderDao { }
