package ua.dp.levelup;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by java on 16.06.2017.
 */
@Retention(value = RetentionPolicy.RUNTIME)
public @interface Profiling {
}
